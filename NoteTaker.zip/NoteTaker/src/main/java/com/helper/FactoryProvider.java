package com.helper;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FactoryProvider {
	
	
	public static SessionFactory factory;
	
	//getFactory will return factory of type SessionFactory 
	//by creating static method we will not require to create an object of the SessionFactory to call method below.
	public static SessionFactory getFactory(){
		
		if(factory == null){
			factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			
		}
		return factory;
	}
	public void closeFactory(){
		if(factory.isOpen()){
			factory.close();
		}
	}
}
